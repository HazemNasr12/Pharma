<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Checkout</title>
    <style>
        /* Your styling goes here */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

        .payment-form {
            max-width: 400px;
            margin: 0 auto;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="number"],
        select {
            width: 100%;
            padding: 8px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }

        button {
            padding: 10px 20px;
            background-color: #337ab7;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #286090;
        }
    </style>
</head>
<body>
    <div class="payment-form">
        <h2>Payment Details</h2>
        <form method="post" action="process_payment.php">
            <div class="form-group">
                <label for="cardholder">Cardholder Name</label>
                <input type="text" id="cardholder" name="cardholder" required>
            </div>
            <div class="form-group">
                <label for="cardtype">Card Type</label>
                <select id="cardtype" name="cardtype" required>
                    <option value="Visa">Visa</option>
                    <option value="MasterCard">MasterCard</option>
                    <!-- Add other card types if needed -->
                </select>
            </div>
            <div class="form-group">
                <label for="cardnumber">Card Number</label>
                <input type="number" id="cardnumber" name="cardnumber" required>
            </div>
            <button type="submit">Pay Now</button>
        </form>
    </div>
</body>
</html>
