<?php
// Start the session to access cart items
session_start();

// Check if the cart is not empty
if (!empty($_SESSION['cart'])) {
    // Connect to your database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ph_db";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch cart items from the database based on the IDs stored in the session
    $cartItems = implode(',', $_SESSION['cart']);
    $sql = "SELECT * FROM products WHERE id IN ($cartItems)";
    $result = $conn->query($sql);

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <style>
            /* Your cart styling here */
            body {
            background: url('cart1.jpg') center/cover no-repeat;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        /* Cart container styles */
        .cart-container {
            padding: 20px;
            max-width: 800px;
            margin: 0 auto;
        }

        /* Cart item styles */
        .cart-item {
            border-bottom: 1px solid #ccc;
            padding: 10px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #07096157;
            color: white;
        }

        .cart-item img {
            width: 90px;
            height: 90px;
            border-radius: 4px;
            margin-right: 20px;
        }

        .cart-item-details {
            flex-grow: 1;
        }

        /* Heading styles */
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        /* General text styles */
        p {
            margin: 5px 0;
        }

        /* Responsive styles */
        @media screen and (max-width: 768px) {
            .cart-container {
                padding: 10px;
            }
            .cart-item {
                flex-direction: column;
                align-items: flex-start;
            }
            .cart-item img {
                margin-bottom: 10px;
            }
        }
        #checkout-btn {
            display: block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #337ab7;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
        }

        #checkout-btn:hover {
            background-color: #286090;
        }
    </style>
</head>
<body>
    <div class="cart-container">
        <h1>Shopping Cart</h1>
        <?php
        if (!empty($result) && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="cart-item">';
                echo '<img src="' . $row['product_image'] . '" alt="' . $row['product_name'] . '">';
                echo '<div class="cart-item-details">';
                echo '<h3>' . $row['product_name'] . '</h3>';
                echo '<p>Price: $' . $row['price'] . '</p>';
                echo '</div>';
                echo '</div>';
            }
            echo '<a href="checkout.php" id="checkout-btn">Proceed To Checkout</a>';
        } else {
            echo "<p>No items in the cart</p>";
        }
        ?>
    </div>
    <script>
        

    </script>
</body>
</html>
