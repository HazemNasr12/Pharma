<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $cardholder = $_POST['cardholder'];
    $cardtype = $_POST['cardtype'];
    $cardnumber = $_POST['cardnumber'];

    // Perform validation and processing (in a real scenario, you'd validate against a database or payment gateway)

    // Simulate a successful payment
    $paymentSuccessful = true; // Assume payment is successful

    if ($paymentSuccessful) {
        echo "<h2>Payment Successful</h2>";
        echo "<p>Cardholder Name: $cardholder</p>";
        echo "<p>Card Type: $cardtype</p>";
        echo "<p>Card Number: $cardnumber</p>";
        echo '<a href="home.html" id="checkout-btn">Return To Home Page</a>';
    } else {
        echo "<h2>Payment Failed</h2>";
        echo "<p>Please check your card details and try again.</p>";
    }
} else {
    // Redirect to the checkout page if accessed without form submission
    header("Location: checkout.php");
    exit;
}

?>
