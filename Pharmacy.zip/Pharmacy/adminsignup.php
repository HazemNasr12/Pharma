<?php
$servername = "localhost";
$username = "root"; // default XAMPP username
$password = ""; // default XAMPP password
$dbname = "ph_db"; // replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pass = mysqli_real_escape_string($conn, $_POST['password']);
    $confirm_pass = mysqli_real_escape_string($conn, $_POST['confirmPassword']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']); // Added gender handling

    if($pass !== $confirm_pass) {
        $error = 'Passwords do not match.';
    } else {
        $sql = "INSERT INTO admins (username, email, password, gender) VALUES ('$user', '$email', '$pass', '$gender')";

        if ($conn->query($sql) === TRUE) {
            header("Location: adminloginx.php");
            exit;
        } else {
            $error = "Error: " . $conn->error;
        }
    }
}

$conn->close();
?>