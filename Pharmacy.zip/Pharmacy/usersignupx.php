<?php
include("connection.php");
include("usersignup.php");
$error = ''; // Initialize the error variable

?>

<!DOCTYPE html>
<html>
<head>
    <title>Signup</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="usersignupstyle.css">
</head>
<body>
    
<div id="form">
        <h1>Signup Form</h1>
        <form action="usersignup.php" method="POST" onsubmit="return isValid()">
            <label>Username:</label>
            <input type="text" id="username" name="username"><br><br>
            <label>Email:</label>
            <input type="email" id="email" name="email"><br><br>
            <label>Password:</label>
            <input type="password" id="password" name="password"><br><br>
            <label>Confirm Password:</label>
            <input type="password" id="confirmPassword" name="confirmPassword"><br><br>
            <label>Phone Number:</label>
            <input type="tel" id="phone_number" name="phone_number"><br><br>
            <label>Gender:</label><br>
            <input type="radio" name="gender" value="Male"> Male
            <input type="radio" name="gender" value="Female"> Female<br><br>
            <input type="submit" value="Signup" class="signup-button">
        </form>
        <?php if($error != '') echo "<p class='error-message'>$error</p>"; ?>
    </div>

    <script>
        function isValid() {
            // Add client-side validation logic here
            // Example:
            var password = document.getElementById("password").value;
            var confirmPassword = document.getElementById("confirmPassword").value;

            if(password != confirmPassword) {
                alert("Passwords do not match.");
                return false;
            }
            
            // Add more validation as required
            return true;
        }
    </script>
</body>
</html>
