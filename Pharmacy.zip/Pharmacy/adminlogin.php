<?php
    include('connection.php');
    if (isset($_POST['submit'])) {
        $username = $_POST['user'];
        $password = $_POST['pass'];

        $sql = "select * from admins where username = '$username' and password = '$password'";  
        $result = mysqli_query($conn, $sql);  
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
        $count = mysqli_num_rows($result);  
        
        if (mysqli_num_rows($result) == 1) {
            // Redirect to a logged-in page or perform other actions upon successful login
            header("Location: adminhome.php");
            exit;
        } else {
            $error = "Invalid username or password. Please try again."; // Set an error message
            // Redirect back to the login page with the error message
            header("Location: adminloginx.php?error=" . urlencode($error));
            exit;
        }   
    }
    ?>