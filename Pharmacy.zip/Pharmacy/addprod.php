<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Establish a database connection (modify with your credentials)
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ph_db";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Collect form data
    $product_name = $_POST['product_name'];
    $quantity = $_POST['quantity'];
    $product_image = $_POST['product_image'];
    $price = $_POST['price'];

    // Prepare the SQL statement to insert data into the products table
    $sql = "INSERT INTO products (product_name, quantity, product_image, price) 
            VALUES ('$product_name', '$quantity', '$product_image', '$price')";

    if ($conn->query($sql) === TRUE) {
        echo "New product added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Product</title>
    <link rel="stylesheet" href="addprodstyle.css"> <!-- Link to your CSS file -->
</head>
<body>
    <header>
        <!-- Your header content goes here -->
    </header>

    <main>
        <div class="add-product-form">
            <h2>Add Product</h2>
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <label for="product_name">Product Name:</label>
                <input type="text" id="product_name" name="product_name" required><br><br>
                
                <label for="quantity">Quantity:</label>
                <input type="number" id="quantity" name="quantity" required><br><br>
                
                <label for="product_image">Image URL:</label>
                <input type="text" id="product_image" name="product_image" required><br><br>
                
                <label for="price">Price:</label>
                <input type="text" id="price" name="price" required><br><br>
                
                <input type="submit" value="Add Product">
            </form>
        </div>
    </main>

    <footer>
        <!-- Your footer content goes here -->
    </footer>
</body>
</html>
