<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Home</title>
    <link rel="stylesheet" href="adminhomestyles.css"> <!-- Link to your CSS file -->
    <!-- Include any necessary JavaScript files or libraries -->
</head>
<body>
    <header>
        <!-- Your header content goes here -->
    </header>

    <main>
        <div class="admin-options">
            <a href="addprod.php" class="add-product">Add Product</a>
            <a href="removeprod.php" class="remove-product">Remove Product</a>
        </div>
        <!-- Other content for the admin panel goes here -->
    </main>

    <footer>
        <!-- Your footer content goes here -->
    </footer>
</body>
</html>
