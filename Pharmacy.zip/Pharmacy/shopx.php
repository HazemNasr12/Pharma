<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ph_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM products";
$result = $conn->query($sql);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Pharmacy Shop</title>
    <style>
        /* style.css */

        /* General styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            
        }

        header {
            background-color: #f2f2f2;
            padding: 10px;
            display: flex;
            justify-content: flex-end;
        }

        #cart {
            margin-right: 20px;
            font-weight: bold;
            font-size: 16px;
        }

        .product-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            padding: 20px;
        }

        .product {
            width: calc(20% - 50px);
            padding: 15px;
            border: 1px solid #ccc;
            border-radius: 8px;
        }

        .product img {
            width: 100%;
            border-radius: 8px;
            margin-bottom: 10px;
        }

        .product h3 {
            margin-top: 0;
            margin-bottom: 10px;
            font-size: 18px;
        }

        .add-to-cart {
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            background-color: #337ab7;
            color: white;
            cursor: pointer;
        }
        .add-to-cart:hover {
            background-color: #286090;
        }

    </style>
</head>
<body>
    <header>
        <a href="cart.php" id="cart"></a>
        <button id="reset-cart">Reset Cart</button>
    </header>

    <div class="product-container">
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="product">';
                echo '<img src="' . $row['product_image'] . '" alt="' . $row['product_name'] . '">';
                echo '<h3>' . $row['product_name'] . '</h3>';
                echo '<p>Quantity: ' . $row['quantity'] . '</p>';
                echo '<p>Price: $' . $row['price'] . '</p>';
                echo '<button class="add-to-cart" data-product-id="' . $row['id'] . '">Add to Cart</button>';
                echo '</div>';
            }
        } else {
            echo "No products found";
        }
        ?>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            let cartCount = localStorage.getItem('cartCount') ? parseInt(localStorage.getItem('cartCount')) : 0;
            const addToCartButtons = document.querySelectorAll('.add-to-cart');
            const cart = document.getElementById('cart');
            const resetCartButton = document.getElementById('reset-cart'); // Assuming you have a button with id 'reset-cart'

            updateCartCount(cartCount);

            addToCartButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const productId = button.getAttribute('data-product-id');
                    addToCart(productId);
                });
            });

            resetCartButton.addEventListener('click', function() {
                resetCart();
            });

            function addToCart(productId) {
                fetch('add_to_cart.php', {
                    method: 'POST',
                    body: JSON.stringify({ productId: productId }),
                    headers: {
                        'Content-Type': 'application/json',
                    },
                })
                .then(response => response.text())
                .then(data => {
                    cartCount = parseInt(data);
                    updateCartCount(cartCount);
                    localStorage.setItem('cartCount', cartCount); // Store cartCount in localStorage
                })
                .catch(error => console.error('Error:', error));
            }

            function resetCart() {
                fetch('add_to_cart.php', {
                    method: 'POST',
                    body: JSON.stringify({ productId: 'reset' }), // Sending a specific identifier 'reset'
                    headers: {
                        'Content-Type': 'application/json',
                    },
                })
                .then(response => response.text())
                .then(data => {
                    cartCount = parseInt(data);
                    updateCartCount(cartCount);
                    localStorage.setItem('cartCount', cartCount); // Store cartCount in localStorage
                })
                .catch(error => console.error('Error:', error));
            }

            function updateCartCount(count) {
                cart.textContent = `Cart (${count})`;
            }
        });

    </script>
</body>
</html>
