<?php
// Connect to the database (use your credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ph_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch products from the database
$sql = "SELECT * FROM products";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h2>Products</h2>";
    echo "<ul>";
    while ($row = $result->fetch_assoc()) {
        echo "<li>";
        echo "Product: " . $row['product_name'] . " - Quantity: " . $row['quantity'] . " - Price: $" . $row['price'];
        echo "<a href='delete_product.php?id=" . $row['id'] . "'>Remove</a>"; // Link to delete_product.php with product ID
        echo "</li>";
    }
    echo "</ul>";
} else {
    echo "No products found";
}

$conn->close();
?>
<head>
    <title>Product List</title>
    <link rel="stylesheet" type="text/css" href="removestyles.css">
</head>