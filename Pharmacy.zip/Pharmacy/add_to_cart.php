<?php
session_start();

// Assuming the received data contains the product ID
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $receivedData = json_decode(file_get_contents('php://input'), true);
    $productId = $receivedData['productId'];

    // Resetting the cart to zero
    if ($productId === 'reset') {
        $_SESSION['cart'] = []; // Set cart to an empty array
        $cartCount = 0; // Reset count to zero
    } else {
        // Add the product ID to the cart session array
        $_SESSION['cart'][] = $productId;

        // Get the count of items in the cart
        $cartCount = count($_SESSION['cart']);
    }

    // Return the cart count as a response
    echo $cartCount;
}
?>
