<?php 
    include("connection.php");
    include("adminlogin.php");
    $error = '';
    ?>
    
    <html>
<head>
    <title>Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="userstyle.css">
</head>
<body>
    <div id="form">
        <h1>Login Form</h1>
        <form name="form" action="adminlogin.php" onsubmit="return isValid()" method="POST">
            <label>Username:</label>
            <input type="text" id="user" name="user" required><br><br>
            <label>Password:</label>
            <input type="password" id="pass" name="pass" required><br><br>
            <input type="submit" id="btn" value="Login" name="submit"/>
        </form>
        <?php
            if(isset($_GET['error']) && !empty($_GET['error'])) {
                $error = $_GET['error'];
                echo "<p style='color:red;'>$error</p>";
            }
        ?>
        <p>Don't Have An Account? <a href="adminsignupx.php">Sign Up Here</a></p>
    </div>

    <script>
        function isValid() {
            // Add client-side validation logic here if needed
            return true;
        }
    </script>
</body>
</html>